package entity;

import java.util.Date;

public class TransLog {
	private Account account;
	private Date date;
	private String address;
	private String transType;
	
	
}
