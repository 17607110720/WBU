package entity;

import java.util.Arrays;

public class Customer {
	private String cname;
	private String custmoerID;
	private String address;
	private Account[] account;
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCustmoerID() {
		return custmoerID;
	}
	public void setCustmoerID(String custmoerID) {
		this.custmoerID = custmoerID;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Account[] getAccount() {
		return account;
	}
	public void setAccount(Account[] account) {
		this.account = account;
	}
	@Override
	public String toString() {
		return "Customer [cname=" + cname + ", custmoerID=" + custmoerID + ", address=" + address + ", account="
				+ Arrays.toString(account) + "]";
	}
	
	
}
