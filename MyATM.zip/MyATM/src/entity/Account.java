package entity;

import java.util.Arrays;
import java.util.Date;

public class Account {
	// private Bank bank;
	// private Customer[] holder;

	private int accountNo;
	private int pwd;
	private String aName;
	// private Date createDate;
	private double balance;

	public Account() {
		super();
	}

	public Account(int accountNo, int pwd, String aName, double balance) {
		super();
		this.accountNo = accountNo;
		this.pwd = pwd;
		this.aName = aName;
		this.balance = balance;
	}

	// public Bank getBank() {
	// return bank;
	// }
	// public void setBank(Bank bank) {
	// this.bank = bank;
	// }
	// public Customer[] getHolder() {
	// return holder;
	// }
	// public void setHolder(Customer[] holder) {
	// this.holder = holder;
	// }
	public int getAccountNo() {
		return accountNo;
	}

	public int getPwd() {
		return pwd;
	}

	public void setPwd(int pwd) {
		this.pwd = pwd;
	}

	public String getaName() {
		return aName;
	}

	public void setaName(String aName) {
		this.aName = aName;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	//
	// public Date getCreateDate() {
	// return createDate;
	// }
	//
	// public void setCreateDate(Date createDate) {
	// this.createDate = createDate;
	// }

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", pwd=" + pwd + ", aName=" + aName + ", balance=" + balance + "]";
	}

	
}
