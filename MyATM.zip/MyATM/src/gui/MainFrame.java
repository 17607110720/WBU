package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import entity.Account;

public class MainFrame extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrame frame = new MainFrame(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainFrame(Account account) {
		setTitle("MyATM");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 619, 479);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);

		JButton btnNewButton = new JButton("\u53D6\u6B3E");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// ȡ��ҳ��
				new WithdrawFrame(account).setVisible(true);
				// return;
			}
		});
		btnNewButton.setBounds(0, 98, 165, 80);
		panel.add(btnNewButton);

		JButton button = new JButton("\u5B58\u6B3E");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// ���ҳ��
				new DepositFrame(account).setVisible(true);
				// return;
			}
		});
		button.setBounds(422, 98, 165, 80);
		panel.add(button);

		JButton button_1 = new JButton("\u8F6C\u8D26");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// ת��ҳ��
				new TransferFrame(account).setVisible(true);
			}
		});
		button_1.setBounds(0, 215, 165, 80);
		panel.add(button_1);

		JButton button_2 = new JButton("\u67E5\u8BE2\u4F59\u989D");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// ��ѯ���ҳ��
				try {
					new QueryFrame(account).setVisible(true);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		button_2.setBounds(422, 215, 165, 80);
		panel.add(button_2);

		JButton button_3 = new JButton("\u9000\u51FA");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// ��ʾȷ�϶Ի��򣬵�ѡ��YES_OPTIONʱ�˳�������
				if (JOptionPane.showConfirmDialog(null, "��ȷ��Ҫ�˳�ϵͳ��", "�˳�ϵͳ",
						JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
					// ��ӭ�´ι���
					JOptionPane.showMessageDialog(null, "��ӭ���´ι��٣�", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
					// �˳������棬���ص�½����
					dispose();
					new LoginFrame().setVisible(true);
				}
			}
		});
		button_3.setBounds(214, 318, 165, 80);
		panel.add(button_3);

		JLabel label = new JLabel("\u4EB2\u7231\u7684\u5BA2\u6237" + account.getaName()
				+ "���ã�\u6B22\u8FCE\u5149\u4E34\uFF0C\u8BF7\u9009\u62E9\u60A8\u7684\u64CD\u4F5C\uFF01");
		label.setBounds(139, 0, 403, 94);
		panel.add(label);
	}
}
