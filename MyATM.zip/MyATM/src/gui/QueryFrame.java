package gui;

import java.awt.EventQueue;
import java.awt.TextArea;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import DAO.BalanceDAO;
import db.DBUtil;
import entity.Account;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import java.awt.Font;

public class QueryFrame extends JFrame {

	private JPanel contentPane;
	private DefaultTableModel model;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					QueryFrame frame = new QueryFrame(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * 
	 * @throws Exception
	 */
	public QueryFrame(Account account) throws Exception {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel label = new JLabel("\u60A8\u7684\u4F59\u989D\u4E3A\uFF1A");
		label.setBounds(142, 12, 142, 50);
		contentPane.add(label);

		model = new DefaultTableModel();

		JButton button = new JButton("\u8FD4\u56DE");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// ���������ʱ���رյ�ǰ���ڣ����ص�������
				dispose();
			}
		});

		button.setBounds(140, 176, 123, 39);
		contentPane.add(button);

		JTextArea textArea = new JTextArea();
		textArea.setFont(new Font("Monospaced", Font.PLAIN, 20));
		textArea.setBounds(112, 67, 205, 50);
		contentPane.add(textArea);

		// ����TextArea����Ϊ��ǰ���
		textArea.setText(new BalanceDAO().balanceDaoForUI(account) + "Ԫ");
	}

}
