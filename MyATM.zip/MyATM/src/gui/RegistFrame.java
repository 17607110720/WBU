package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.synth.SynthSeparatorUI;

import DAO.AccountDAO;
import DAO.RegisterDAO;
import entity.Account;

public class RegistFrame extends JFrame {

	private JPanel contentPane;
	private JTextField textAccount;
	private JPasswordField textPwd;
	private JPasswordField textPwd1;
	private JTextField textName;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegistFrame frame = new RegistFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RegistFrame() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setFont(new Font("����", Font.PLAIN, 12));
		setTitle("ע��");
		// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 561, 414);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);

		JLabel label = new JLabel("�� ����");
		label.setFont(new Font("����", Font.PLAIN, 18));
		label.setBounds(50, 35, 81, 21);
		panel.add(label);

		textAccount = new JTextField();
		textAccount.setBounds(146, 30, 243, 32);
		panel.add(textAccount);
		textAccount.setColumns(10);

		JLabel label_1 = new JLabel("�� �룺");
		label_1.setFont(new Font("����", Font.PLAIN, 18));
		label_1.setBounds(50, 147, 81, 21);
		panel.add(label_1);

		JLabel label_2 = new JLabel("ȷ�����룺");
		label_2.setFont(new Font("����", Font.PLAIN, 18));
		label_2.setBounds(50, 206, 101, 32);
		panel.add(label_2);

		JButton btnNewButton = new JButton("ע��");
		btnNewButton.setFont(new Font("����", Font.PLAIN, 18));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String accountNo = textAccount.getText();
				String name = textName.getText();
				String pwd = new String(textPwd.getPassword());
				String pwd1 = new String(textPwd1.getPassword());
				if (null == accountNo || "".equals(accountNo)) {
					JOptionPane.showMessageDialog(null, "�˻�����Ϊ�գ�", "�������", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if (null == name || "".equals(name)) {
					JOptionPane.showMessageDialog(null, "�˻���������Ϊ�գ�", "�������", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if (null == pwd || "".equals(pwd) || null == pwd1 || "".equals(pwd1)) {
					JOptionPane.showMessageDialog(null, "���벻��Ϊ�գ�", "�������", JOptionPane.ERROR_MESSAGE);
					return;
				} else if (!(pwd.equals(pwd1))) {
					JOptionPane.showMessageDialog(null, "�����������벻һ����", "�������", JOptionPane.ERROR_MESSAGE);
					return;
				}

				// �������ݿ�ע��
				Account account1 = new Account(Integer.parseInt(accountNo), Integer.parseInt(pwd), name, 0);
				// ����ע���˻�DAO����
				RegisterDAO rs = new RegisterDAO();
				// ����ע�᷽��registerDao�������������ݿ��е������˻�����
				try {
					// DAO��������true����ʾע��ɹ�
					boolean temp = rs.registerDao(account1);
					if (temp) {
						JOptionPane.showMessageDialog(null, "ע��ɹ���", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
						// ע��ɹ����ر�ע�ᴰ��
						dispose();
					} else {
						JOptionPane.showMessageDialog(null, "�˻��Ѿ����ڣ�ע��ʧ�ܣ�", "������ʾ", JOptionPane.ERROR_MESSAGE);
					}
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setBounds(60, 280, 123, 29);
		panel.add(btnNewButton);

		JButton button = new JButton("����");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textAccount.setText(null);
				textPwd.setText(null);
				textPwd1.setText(null);
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(300, 280, 123, 29);
		panel.add(button);

		textPwd = new JPasswordField();
		textPwd.setBounds(148, 144, 243, 32);
		panel.add(textPwd);

		textPwd1 = new JPasswordField();
		textPwd1.setBounds(148, 209, 243, 32);
		panel.add(textPwd1);

		JLabel label_3 = new JLabel("\u59D3 \u540D\uFF1A");
		label_3.setFont(new Font("����", Font.PLAIN, 18));
		label_3.setBounds(50, 90, 81, 21);
		panel.add(label_3);

		textName = new JTextField();
		textName.setColumns(10);
		textName.setBounds(146, 87, 243, 32);
		panel.add(textName);
	}
}
