package gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import DAO.AccountDAO;
import DAO.TransactionDAO;
import entity.Account;
import service.DepositService;

public class DepositFrame extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DepositFrame frame = new DepositFrame(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DepositFrame(Account account) {
		setTitle("\u5B58\u6B3E");
		// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("\u8BF7\u8F93\u5165\u60A8\u6240\u5B58\u5165\u7684\u91D1\u989D\uFF1A");
		lblNewLabel.setBounds(133, 41, 198, 41);
		contentPane.add(lblNewLabel);

		textField = new JTextField();
		textField.setBounds(133, 97, 136, 41);
		contentPane.add(textField);
		textField.setColumns(10);

		JButton btnNewButton = new JButton("\u786E\u8BA4");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// ���׶��Ϊ��
				String textMoney = textField.getText();
				if (null == textMoney || "".equals(textMoney)) {
					JOptionPane.showMessageDialog(null, "����Ϊ�գ�", "�������", JOptionPane.ERROR_MESSAGE);
					return;
				}
				double money = Double.parseDouble(textField.getText());
				// ���
				try {
					// ���׶����Ϊ����
					if (money >= 0) {
						// ȷ�Ͻ��׶�
						if (JOptionPane.showConfirmDialog(null, "��ȷ������ȡ���" + money + "Ԫ", "��ʾ",
								JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
							account.setBalance(account.getBalance() + money);
							new TransactionDAO().transactionDao(account);
							JOptionPane.showMessageDialog(null, "���ɹ���", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
							// return;
						}
					} else {
						JOptionPane.showMessageDialog(null, "����������", "������ʾ", JOptionPane.ERROR_MESSAGE);
					}
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setBounds(62, 181, 123, 41);
		contentPane.add(btnNewButton);

		JButton button = new JButton("\u8FD4\u56DE");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// ���������ʱ���رյ�ǰ���ڣ����ص�������
				dispose();
			}
		});
		button.setBounds(239, 181, 123, 41);
		contentPane.add(button);
	}
}
