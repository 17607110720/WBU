package gui;

public class RemAccountFrame {

}
