package service;

import java.util.Date;

import entity.Account;

public abstract class Transaction {
	private Account account;
	private double money;
	private Date createDate;

	// �������׼�¼
	public abstract void newTransaction(Account account, Date date) throws Exception;

	// ���潻�׼�¼
	public abstract void save(Account account) throws Exception;
}
